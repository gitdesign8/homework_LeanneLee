$(function(){

    // Build your arrays
    var products    = ['Patience', 'Respect', 'Intuition', 'Empathy','Generosity', 'Loyalty', 'Time', 'Kindness', 'Courage', 'Compassion', 'Integrity', 'Hope', 'Humility', 'Gratitude', 'Honesty'];
    var images = ['patience.svg', 'respect.svg', 'intuition.svg', 'empathy.svg','generosity.svg','loyalty.svg', 'time.svg', 'kindness.svg', 'courage.svg', 'compassion.svg', 'integrity.svg', 'hope.svg', 'humility.svg', 'gratitude.svg', 'honesty.svg'];
    var pricing = ['4', '7', '8', '4', '10','4', '7', '8', '4', '10','4', '7', '8', '4', '10'];
    var quantity = ['4', '2', '8','10', '3','4', '2', '8','10', '3','4', '2', '8','10', '3'];
    var cart = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];


    // Add products to the store
    $.each(products, function(index, value){
        var inventory = "";
        var image = images[index] || 'default.svg';

        inventory += '<div class="productcards">';
        inventory +=	'<h4 class="productname">' + products[index] + '</h4>';
        inventory += 	'<h5 class ="price">' + pricing[index] + ' veraques</h5>';
        inventory += 	'<img class="productimage" src="' + image + '"/>';
        inventory +=    '<div class="quantity">Qty';
        inventory += 		'<select id="'+ value +'Select" class="dropdown">';

    //I'm having some problems getting the quantity to link up to the quantity array above
        inventory +=              '<option value=1>1</option>';
        inventory +=              '<option value=2>2</option>';
        inventory +=              '<option value=3>3</option>';
        inventory +=         '</select>';
        inventory += 	'</div>';
        inventory +=    '<button class="btn" value=' + index +   '>Add</button>';
        // Fire this code so it launches into the DOM
        $('#products').append(inventory);
    });



        // Now I need to figure out how to add the products with the click
        //function and have it show up in the cart.

    $('#products').on('click', '.btn', function(button){
        var index = $(this).val();
        cart[index]++;
        console.log(cart);
    });

    $('#viewCart').on('click', function(){
        //Clear the cart
        $('#cartContents').html('');

        //Build the cart
        for(var i = 0; i < products.length; i++)
        {
            var count = cart[i];
            if(count > 0) {
                var string = "";

                string += '<li class="list-group-item clearfix">';
                string += products[i];
                string += '<span>' + count + '</span>';
                string += '</li>';

                $('#cartContents').append(string);
            }
        }
    });

function buildSelect(i){

    var product = products[i];
    var inventory = inventory[i];
    var string = '';

    string +='<select id="' + product + 'Select">';
    var max = quantity || 0;
    for(var j = 1; j <= max; j++)
    {
        string += '<option value=' + j + '>' + j + '</option>';
    }
    string +='</select>';

    return string;
}



});