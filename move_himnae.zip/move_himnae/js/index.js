
$( '#greenButton' ).click(function() {
  $( ".himnae2" ).animate({ ".himnae2": "+=50px" }, "slow" );
});

$( "#yelloButton" ).click(function(){
  $( ".himnae2" ).animate({ ".himnae2": "-=50px" }, "slow" );
});
	

